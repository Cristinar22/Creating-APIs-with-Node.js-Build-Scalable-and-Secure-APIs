# Test your API
# Open Postman and send a GET request to:
# http://localhost:3000/
# You should see the 'Hello, World!' message in the response.