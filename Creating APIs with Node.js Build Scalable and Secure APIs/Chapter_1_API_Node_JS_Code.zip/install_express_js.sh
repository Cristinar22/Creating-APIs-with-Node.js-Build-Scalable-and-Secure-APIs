# Install Express.js
# Express.js is used to build APIs quickly and easily with Node.js.
npm install express