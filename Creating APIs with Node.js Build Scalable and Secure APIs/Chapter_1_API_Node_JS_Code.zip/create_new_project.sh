# Create a new Node.js project
mkdir my-api-project
cd my-api-project
npm init -y