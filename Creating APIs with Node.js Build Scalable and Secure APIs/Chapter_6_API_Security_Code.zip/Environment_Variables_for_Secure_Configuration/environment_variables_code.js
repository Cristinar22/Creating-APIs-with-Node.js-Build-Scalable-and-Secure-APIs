# Install dotenv
npm install dotenv

# Set Up .env File
MONGO_URI=mongodb://localhost:27017/mydb
JWT_SECRET=mySuperSecretKey

# Access environment variables in the app
require('dotenv').config();
const mongoose = require('mongoose');

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log('Error connecting to MongoDB:', err));

const jwtSecret = process.env.JWT_SECRET;
