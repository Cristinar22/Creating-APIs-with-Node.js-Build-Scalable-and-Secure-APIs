# Install express-validator
npm install express-validator

# POST route to register a new user
const { body, validationResult } = require('express-validator');

app.post(
  '/register',
  [
    body('email').isEmail().withMessage('Please enter a valid email address'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long'),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const { email, password } = req.body;
    res.send('User registered');
  }
);

# Input sanitization
app.post('/register', 
  body('email').normalizeEmail(), // Clean email
  body('password').trim() // Remove leading/trailing spaces
);
