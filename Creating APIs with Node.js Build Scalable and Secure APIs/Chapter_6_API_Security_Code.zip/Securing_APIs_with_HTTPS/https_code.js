# Create the SSL Certificate
openssl genpkey -algorithm RSA -out private.key
openssl req -new -key private.key -out csr.pem
openssl x509 -req -in csr.pem -signkey private.key -out cert.pem

# Set Up HTTPS in Your Node.js Application
npm install https fs
const https = require('https');
const fs = require('fs');
const express = require('express');
const app = express();
const port = 3000;

const options = {
  key: fs.readFileSync('private.key'),
  cert: fs.readFileSync('cert.pem')
};

app.get('/', (req, res) => {
  res.send('Hello, HTTPS!');
});

https.createServer(options, app).listen(port, () => {
  console.log(`Server running at https://localhost:${port}`);
});
