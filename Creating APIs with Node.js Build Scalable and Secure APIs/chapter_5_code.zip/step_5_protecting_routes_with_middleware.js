// Middleware to protect routes and check for admin role
const authMiddleware = (roles = []) => {
  return async (req, res, next) => {
    // Check for token in the Authorization header
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) return res.status(401).send('Access denied. No token provided.');

    try {
      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = decoded;

      // Check for role-based access
      if (roles.length && !roles.includes(decoded.role)) {
        return res.status(403).send('Access forbidden. Insufficient privileges.');
      }

      next();
    } catch (error) {
      res.status(400).send('Invalid token');
    }
  };
};

// Example of a protected route accessible only by admins
app.get('/admin', authMiddleware(['admin']), (req, res) => {
  res.send('Welcome, Admin!');
});