app.post('/books', async (req, res) => {
  try {
    const { title, author, publishedDate } = req.body;
    const book = new Book({ title, author, publishedDate });
    await book.save();
    res.status(201).json(book);
  } catch (error) {
    res.status(400).json({ message: 'Error creating book', error: error.message });
  }
});