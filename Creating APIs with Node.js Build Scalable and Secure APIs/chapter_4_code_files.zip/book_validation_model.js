const bookSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Title is required'],
    minlength: [3, 'Title must be at least 3 characters long']
  },
  author: {
    type: String,
    required: [true, 'Author is required']
  },
  publishedDate: {
    type: Date,
    required: [true, 'Published date is required']
  }
});