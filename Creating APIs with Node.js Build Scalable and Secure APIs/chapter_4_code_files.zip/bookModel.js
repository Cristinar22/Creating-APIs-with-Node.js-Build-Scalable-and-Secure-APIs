const mongoose = require('mongoose');

// Define a schema for the Book model
const bookSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    minlength: 3
  },
  author: {
    type: String,
    required: true
  },
  publishedDate: {
    type: Date,
    required: true
  }
});

// Create a Book model from the schema
const Book = mongoose.model('Book', bookSchema);

module.exports = Book;