
describe('PUT /books/:id', () => {
  it('should update the title of the book', (done) => {
    const updatedBook = { title: 'Brave New World' };

    chai.request(app)
      .put('/books/1')
      .send(updatedBook)
      .end((err, res) => {
        expect(res).to.have.status(200);
        expect(res.body).to.have.property('title').eql('Brave New World');
        done();
      });
  });
});
