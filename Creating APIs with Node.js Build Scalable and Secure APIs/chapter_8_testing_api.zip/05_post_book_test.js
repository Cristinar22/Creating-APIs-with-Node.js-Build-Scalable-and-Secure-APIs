
it('should create a new book', (done) => {
  const bookData = { title: 'The Great Gatsby', author: 'F. Scott Fitzgerald' };

  chai.request(app)
    .post('/books')
    .send(bookData)
    .end((err, res) => {
      expect(res).to.have.status(201);
      expect(res.body).to.have.property('title').eql('The Great Gatsby');
      expect(res.body).to.have.property('author').eql('F. Scott Fitzgerald');
      done();
    });
});
