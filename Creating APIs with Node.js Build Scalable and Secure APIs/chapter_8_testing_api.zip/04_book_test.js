
const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../server'); // Assuming your server file is named 'server.js'

chai.use(chaiHttp);
const { expect } = chai;

describe('GET /books/:id', () => {
  it('should return a book when a valid ID is provided', (done) => {
    chai.request(app)
      .get('/books/1')
      .end((err, res) => {
        expect(res).to.have.status(200);
        expect(res.body).to.have.property('title').eql('1984');
        done();
      });
  });

  it('should return a 404 error when the book is not found', (done) => {
    chai.request(app)
      .get('/books/999')
      .end((err, res) => {
        expect(res).to.have.status(404);
        expect(res.body).to.have.property('message').eql('Book not found');
        done();
      });
  });
});
