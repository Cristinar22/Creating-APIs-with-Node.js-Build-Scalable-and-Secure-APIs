app.get('/books/:id', (req, res) => {
  debugger;  // This will pause execution when this line is hit
  const book = books.find((b) => b.id == req.params.id);
  res.json(book);
});