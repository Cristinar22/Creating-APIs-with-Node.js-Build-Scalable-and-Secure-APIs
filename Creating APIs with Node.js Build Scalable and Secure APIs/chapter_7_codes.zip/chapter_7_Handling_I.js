app.get('/books/:id', (req, res) => {
  try {
    const book = books.find((b) => b.id == req.params.id);
    
    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }
    
    res.json(book);
  } catch (error) {
    // If an error occurs, respond with a 500 status code
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});