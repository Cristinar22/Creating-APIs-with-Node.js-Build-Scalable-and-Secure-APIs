const winston = require('winston');

// Create a logger instance
const logger = winston.createLogger({
  level: 'info',  // Log level
  transports: [
    new winston.transports.Console({ format: winston.format.simple() }),
    new winston.transports.File({ filename: 'app.log' })
  ]
});

// Example of logging
app.get('/books/:id', (req, res) => {
  const book = books.find((b) => b.id == req.params.id);
  
  if (!book) {
    logger.error('Book not found');
    return res.status(404).json({ message: 'Book not found' });
  }

  logger.info(`Book found: ${book.title}`);
  res.json(book);
});