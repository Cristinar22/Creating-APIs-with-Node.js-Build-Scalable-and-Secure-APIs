app.post('/register', (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  // Simulate a server-side error
  try {
    // Simulate database error
    throw new Error('Database connection failed');

  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Failed to register user. Please try again later.' });
  }
});