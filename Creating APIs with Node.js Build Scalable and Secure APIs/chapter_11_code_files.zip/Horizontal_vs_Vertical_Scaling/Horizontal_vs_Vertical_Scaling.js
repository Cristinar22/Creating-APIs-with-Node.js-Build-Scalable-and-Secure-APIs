// Horizontal vs Vertical Scaling Code Example
console.log("Horizontal scaling is about adding more servers, while vertical scaling adds more resources to a single server.");