// Load Balancing Strategy Code Example - Round-Robin
const http = require('http');
const servers = ["Server1", "Server2", "Server3"];
let currentServer = 0;
http.createServer((req, res) => {
    res.writeHead(200);
    res.end(`Redirected to: ${servers[currentServer]}`);
    currentServer = (currentServer + 1) % servers.length;
}).listen(3000);