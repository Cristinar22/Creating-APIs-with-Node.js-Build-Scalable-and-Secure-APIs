// AWS EC2 Setup Code Example
const AWS = require('aws-sdk');
AWS.config.update({region: 'us-west-2'});
console.log("Setting up EC2 instance...");