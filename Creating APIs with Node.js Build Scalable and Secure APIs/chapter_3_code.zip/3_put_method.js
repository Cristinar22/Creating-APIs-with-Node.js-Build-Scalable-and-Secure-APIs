app.put('/users/:id', (req, res) => {
  const { id } = req.params;
  const { email } = req.body;
  res.send(`User with ID ${id} has been updated with new email: ${email}`);
});