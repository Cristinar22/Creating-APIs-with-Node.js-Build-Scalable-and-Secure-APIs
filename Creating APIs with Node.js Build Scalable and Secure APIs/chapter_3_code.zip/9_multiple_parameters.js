app.get('/users/:id', (req, res) => {
  const { id } = req.params;
  const { name, age } = req.query;
  res.send(`Fetching user with ID: ${id}, Name: ${name}, Age: ${age}`);
});