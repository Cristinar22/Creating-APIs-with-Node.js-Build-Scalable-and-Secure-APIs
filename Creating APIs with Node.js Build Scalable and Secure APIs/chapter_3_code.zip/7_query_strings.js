app.get('/users', (req, res) => {
  const { name } = req.query;
  res.send(`Searching for user with name: ${name}`);
});