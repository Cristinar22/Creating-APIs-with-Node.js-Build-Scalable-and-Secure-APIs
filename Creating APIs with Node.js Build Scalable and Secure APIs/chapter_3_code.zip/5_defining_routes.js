const express = require('express');
const app = express();
const port = 3000;

app.get('/users', (req, res) => {
  res.send('Fetching all users');
});

app.post('/users', (req, res) => {
  res.send('Creating a new user');
});

app.delete('/users/:id', (req, res) => {
  const { id } = req.params;
  res.send(`User with ID ${id} deleted`);
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});