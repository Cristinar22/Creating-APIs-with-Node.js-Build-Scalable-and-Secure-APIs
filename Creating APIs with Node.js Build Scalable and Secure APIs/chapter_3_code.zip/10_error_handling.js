app.delete('/users/:id', (req, res) => {
  const { id } = req.params;

  if (id !== '123') {
    res.status(404).send('User not found');
  } else {
    res.send(`User with ID ${id} deleted`);
  }
});