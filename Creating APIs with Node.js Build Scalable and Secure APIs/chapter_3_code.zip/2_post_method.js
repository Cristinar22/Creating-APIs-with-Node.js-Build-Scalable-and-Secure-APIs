app.post('/users', (req, res) => {
  const { name, email } = req.body;
  res.send(`User ${name} with email ${email} created.`);
});