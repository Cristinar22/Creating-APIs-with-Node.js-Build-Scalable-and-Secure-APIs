app.delete('/users/:id', (req, res) => {
  const { id } = req.params;
  res.send(`User with ID ${id} has been deleted.`);
});