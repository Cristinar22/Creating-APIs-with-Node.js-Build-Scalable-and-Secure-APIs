app.get('/users', (req, res) => {
  res.send('Returning all users');
});