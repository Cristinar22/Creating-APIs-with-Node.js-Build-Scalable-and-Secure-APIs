const express = require('express');
const mongoose = require('mongoose');
const redis = require('redis');
const app = express();
const port = 3000;

const redisClient = redis.createClient();

// Connect to Redis
redisClient.on('connect', () => {
  console.log('Connected to Redis');
});

// Sample data for books
let books = [
  { id: 1, title: '1984', author: 'George Orwell' },
  { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee' }
];

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/bookstore', { useNewUrlParser: true, useUnifiedTopology: true });

// GET route to fetch all books with caching
app.get('/books', (req, res) => {
  redisClient.get('allBooks', (err, booksData) => {
    if (booksData) {
      // If data exists in Redis, send it
      return res.json(JSON.parse(booksData));
    }

    // If no cached data, fetch from database
    const booksFromDb = books; // This would be a MongoDB query in a real app
    redisClient.setex('allBooks', 3600, JSON.stringify(booksFromDb)); // Cache data for 1 hour
    res.json(booksFromDb);
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
