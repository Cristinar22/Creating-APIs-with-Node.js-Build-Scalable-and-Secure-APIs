const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
  publishedDate: Date
});

bookSchema.index({ author: 1 }); // Create an index on the author field

const Book = mongoose.model('Book', bookSchema);

// Query to retrieve only the title and author fields
Book.find({ author: 'George Orwell' }, 'title author', (err, books) => {
  if (err) {
    console.log(err);
  }
  console.log(books); // Only the title and author fields are returned
});
