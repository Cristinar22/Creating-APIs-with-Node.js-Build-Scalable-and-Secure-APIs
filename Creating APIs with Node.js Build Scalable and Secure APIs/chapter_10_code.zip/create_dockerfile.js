
    # Use official Node.js image from Docker Hub
    FROM node:14
    
    # Set the working directory inside the container
    WORKDIR /usr/src/app
    
    # package.json and install dependencies
    package*.json ./
    RUN npm install
    
    # the rest of the application code
    . .
    
    # Expose the port the app runs on
    EXPOSE 5000
    
    # Command to run the application
    CMD ["node", "server.js"]
    