
    heroku ps:scale web=1
    