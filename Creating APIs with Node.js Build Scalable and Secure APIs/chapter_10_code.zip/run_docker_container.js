
    docker run -p 5000:5000 my-api
    