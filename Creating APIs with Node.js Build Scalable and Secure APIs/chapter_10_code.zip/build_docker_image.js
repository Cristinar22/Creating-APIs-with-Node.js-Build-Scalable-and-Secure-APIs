
    docker build -t my-api .
    