
    mkdir my-api
    cd my-api
    npm init -y
    npm install express
    