
    heroku logs --tail
    