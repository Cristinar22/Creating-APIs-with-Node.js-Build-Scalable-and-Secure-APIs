const { ApolloServer, gql } = require('apollo-server-express');
const express = require('express');
const app = express();

// Define your schema
const typeDefs = gql`
  type Book {
    title: String
    author: String
  }

  type Query {
    books: [Book]
  }
`;

// Define your resolvers
const resolvers = {
  Query: {
    books: () => [
      { title: '1984', author: 'George Orwell' },
      { title: 'To Kill a Mockingbird', author: 'Harper Lee' },
    ],
  },
};

// Create an ApolloServer instance
const server = new ApolloServer({ typeDefs, resolvers });

// Apply middleware
server.applyMiddleware({ app });

// Start the server
app.listen(4000, () => {
  console.log('Server running at http://localhost:4000/graphql');
});
