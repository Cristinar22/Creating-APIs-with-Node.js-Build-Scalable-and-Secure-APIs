const express = require('express');
const app = express();

app.get('/users', (req, res) => {
  // Return a list of users
  res.json([{ id: 1, name: 'John Doe' }]);
});

app.listen(3001, () => {
  console.log('User service running on http://localhost:3001');
});
