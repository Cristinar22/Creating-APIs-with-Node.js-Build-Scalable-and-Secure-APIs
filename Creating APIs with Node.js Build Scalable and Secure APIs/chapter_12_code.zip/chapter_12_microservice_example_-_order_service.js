const express = require('express');
const app = express();

app.get('/orders', (req, res) => {
  // Return a list of orders
  res.json([{ id: 101, userId: 1, total: 200 }]);
});

app.listen(3002, () => {
  console.log('Order service running on http://localhost:3002');
});
