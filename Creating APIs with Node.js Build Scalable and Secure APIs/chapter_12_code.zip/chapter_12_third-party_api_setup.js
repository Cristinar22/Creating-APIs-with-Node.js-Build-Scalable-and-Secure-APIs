const stripe = require('stripe')('your_stripe_secret_key');

app.post('/payment', async (req, res) => {
  try {
    const { amount, token } = req.body;

    const charge = await stripe.charges.create({
      amount, // amount in cents
      currency: 'usd',
      description: 'Payment for services',
      source: token,
    });

    res.status(200).send({ message: 'Payment successful', charge });
  } catch (error) {
    res.status(500).send({ error: 'Payment failed', details: error });
  }
});
