const axios = require('axios');

app.get('/orders', async (req, res) => {
  const userResponse = await axios.get('http://localhost:3001/users');
  const user = userResponse.data[0];

  res.json([{ id: 101, userId: user.id, total: 200 }]);
});
