npm install express
npm install --save-dev nodemon
