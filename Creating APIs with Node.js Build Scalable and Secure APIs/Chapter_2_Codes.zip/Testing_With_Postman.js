# Testing with Postman
GET http://localhost:3000/
