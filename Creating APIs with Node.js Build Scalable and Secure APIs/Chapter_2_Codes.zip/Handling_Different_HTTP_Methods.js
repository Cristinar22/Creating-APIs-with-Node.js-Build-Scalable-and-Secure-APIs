app.use(express.json()); // To parse JSON request bodies

app.post('/submit', (req, res) => {
  const { name, age } = req.body;
  res.send(`Received name: ${name}, age: ${age}`);
});

app.put('/update', (req, res) => {
  const { id, name } = req.body;
  res.send(`Updated record with ID: ${id}, new name: ${name}`);
});

app.delete('/delete/:id', (req, res) => {
  const { id } = req.params;
  res.send(`Deleted record with ID: ${id}`);
});
