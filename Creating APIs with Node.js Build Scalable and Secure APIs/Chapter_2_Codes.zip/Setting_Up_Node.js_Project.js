mkdir first-api
cd first-api
npm init -y
