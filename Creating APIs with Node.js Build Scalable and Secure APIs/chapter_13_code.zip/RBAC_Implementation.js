
const roles = {
  admin: 'admin',
  user: 'user'
};

const express = require('express');
const app = express();

// Middleware to check roles
const checkRole = (role) => {
  return (req, res, next) => {
    const userRole = req.user.role; // Assume the role is set on the user object
    if (userRole !== role) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    next();
  };
};

// Admin-only route
app.get('/admin/data', checkRole(roles.admin), (req, res) => {
  res.send('Admin data');
});

// User route
app.get('/user/data', checkRole(roles.user), (req, res) => {
  res.send('User data');
});

app.listen(3000, () => {
  console.log('Server running');
});
