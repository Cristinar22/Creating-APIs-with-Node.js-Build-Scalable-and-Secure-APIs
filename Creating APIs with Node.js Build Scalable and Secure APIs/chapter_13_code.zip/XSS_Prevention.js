
const xss = require('xss'); // An npm package for sanitizing input

app.post('/comment', (req, res) => {
  const sanitizedComment = xss(req.body.comment); // sanitize user input
  // Store sanitized comment in database
  res.send('Comment saved');
});
