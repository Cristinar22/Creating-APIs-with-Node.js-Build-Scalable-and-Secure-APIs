
const userId = req.params.userId;
const query = 'SELECT * FROM users WHERE id = $1';
const values = [userId];
client.query(query, values)
  .then(result => res.json(result.rows))
  .catch(e => console.error(e.stack));
